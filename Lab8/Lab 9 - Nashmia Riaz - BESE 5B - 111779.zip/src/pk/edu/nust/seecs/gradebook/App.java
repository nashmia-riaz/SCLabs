package pk.edu.nust.seecs.gradebook;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import pk.edu.nust.seecs.gradebook.BOs.*;
import pk.edu.nust.seecs.gradebook.dao.*;
import pk.edu.nust.seecs.gradebook.entity.*;

/**
 * My main App. 
 * <p>
 This executes everything.
 */

public class App {

    private CloBO clobo;
    private ContentBO contentbo;
    private CourseBO coursebo;
    private GradeBO gradebo;
    private StudentBO studentbo;
    private TeacherBO teacherbo;

    public void main(String[] args) {
        Teacher t = new Teacher();
        t.setName("Mudassir Something");
        t.setTeacherID(1);

        Student s = new Student("Nashmia Riaz");
        Course HCI = new Course();
        HCI.setClasstitle("Human Computer Interaction");
        HCI.setCreditHours(3);
        HCI.setCourseID(1);
        HCI.setStartsOn(new Date(2016, 9, 1));
        HCI.setEndsOn(new Date(2017, 1, 20));

        HCI.setTeacher(t);
        studentbo.addStudent(s);
        coursebo.addCourse(HCI);

        boolean exit = false;
        int option;

        System.out.print("Enter one of the following: \n"+
                "1. Add\n"+
                "2. Delete\n" +
                "3. Update\n");

        Scanner input = new Scanner(System.in);
        option = input.nextInt();

        System.out.print("Enter one of the following: \n"+
                "1. Clo\n"+
                "2. Content\n" +
                "3. Course\n" +
                "4. Grade\n" +
                "5. Student\n" +
                "6. Teacher\n");
        int option2 = input.nextInt();

        switch(option){
            case 1:
                switch(option2){
                    case 1:
                        CloBO clobo = new CloBO();
//                        Clo cl = new Clo("1","hello","plo","bt");
//                        clobo.addClo(cl);
                        break;

                    case 2:
                        break;

                    case 3:
                        break;

                    case 4:
                        break;

                    case 5:
                        break;

                    case 6:
                        break;
                }
                break;

            case 2:
                break;

            case 3:
                break;
        }
    }

}