/**
 * Created by nashm on 29/03/2017.
 */
public class user {

    private String userid;
    private String scheme;
    private float timeTaken1;
    private boolean state1;
    private float timeTaken2;
    private boolean state2;
    private float timeTaken3;
    private boolean state3;
    private float timeTaken4;
    private boolean state4;
    private float timeTaken5;
    private boolean state5;
    private float timeTaken6;
    private boolean state6;
    private float timeTaken7;
    private boolean state7;
    private float timeTaken8;
    private boolean state8;

    public boolean isState8() {
        return state8;
    }

    public void setState8(boolean state8) {
        this.state8 = state8;
    }

    public float getTimeTaken8() {
        return timeTaken8;
    }

    public void setTimeTaken8(float timeTaken8) {
        this.timeTaken8 = timeTaken8;
    }

    public boolean isState7() {
        return state7;
    }

    public void setState7(boolean state7) {
        this.state7 = state7;
    }

    public float getTimeTaken7() {
        return timeTaken7;
    }

    public void setTimeTaken7(float timeTaken7) {
        this.timeTaken7 = timeTaken7;
    }

    public boolean isState6() {
        return state6;
    }

    public void setState6(boolean state6) {
        this.state6 = state6;
    }

    public float getTimeTaken6() {
        return timeTaken6;
    }

    public void setTimeTaken6(float timeTaken6) {
        this.timeTaken6 = timeTaken6;
    }

    public boolean isState5() {
        return state5;
    }

    public void setState5(boolean state5) {
        this.state5 = state5;
    }

    public float getTimeTaken5() {
        return timeTaken5;
    }

    public void setTimeTaken5(float timeTaken5) {
        this.timeTaken5 = timeTaken5;
    }

    public boolean isState4() {
        return state4;
    }

    public void setState4(boolean state4) {
        this.state4 = state4;
    }

    public float getTimeTaken4() {
        return timeTaken4;
    }

    public void setTimeTaken4(float timeTaken4) {
        this.timeTaken4 = timeTaken4;
    }

    public boolean isState3() {
        return state3;
    }

    public void setState3(boolean state3) {
        this.state3 = state3;
    }

    public float getTimeTaken3() {
        return timeTaken3;
    }

    public void setTimeTaken3(float timeTaken3) {
        this.timeTaken3 = timeTaken3;
    }

    public boolean isState2() {
        return state2;
    }

    public void setState2(boolean state2) {
        this.state2 = state2;
    }

    public float getTimeTaken2() {
        return timeTaken2;
    }

    public void setTimeTaken2(float timeTaken2) {
        this.timeTaken2 = timeTaken2;
    }

    public boolean isState1() {
        return state1;
    }

    public void setState1(boolean state1) {
        this.state1 = state1;
    }

    public float getTimeTaken1() {
        return timeTaken1;
    }

    public void setTimeTaken1(float timeTaken1) {
        this.timeTaken1 = timeTaken1;
    }

    public String getScheme() {
        return scheme;
    }

    public void setScheme(String scheme) {
        this.scheme = scheme;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }
}
