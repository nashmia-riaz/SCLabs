
function(doc) {
    emit([doc.first, doc.last], doc);
}