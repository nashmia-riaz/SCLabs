function(doc) {
    if(doc.city) {
        emit(doc.city);
    }
}