function(doc) {
    emit(doc, doc);
}

